jquery-isystkSlider
====

## Description

## Demo
https://demo.isystk.com/jquery-isystkSlider/

## VS. 

## Requirement

## Usage

## Install

``` bash
# install
$ yarn install

# static generate
$ yarn run generate

# server start
$ yarn run dev
$ open http://localhost:3000/
```

## Contribution

## Licence

[MIT](https://github.com/isystk/jquery-isystkSlider/LICENCE)

## Author

[isystk](https://github.com/isystk)


