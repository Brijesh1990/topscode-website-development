import './assets/css/normalize.css';
import './assets/css/prettify.css';
import './assets/index.css';

var $ = require('./assets/js/jquery-3.4.1.min.js');
window.$ = $;
window.jQuery = $;
require('./assets/js/prettify.js');
require('./assets/js/lang-css.js');
require('./assets/js/jquery-stickyNavigator.js');
require('./assets/js/jquery-isystkSlider.js');
require('./assets/js/common.js');
